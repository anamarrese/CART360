/*----------------------------------------------------------------------------*/
/*------------------------------ SHIFT REGISTER ------------------------------*/
/*----------------------------------------------------------------------------*/
/*----------      IMPLEMENT THE SHIFT REGISTER FUNCTIONALITY        ----------*/
/*----------          ******** ATTRIBUTE YOUR CODE ********         ----------*/
/*----------------------------------------------------------------------------*/

#ifndef SHIFTREGISTER_H_
#define SHIFTREGISTER_H_

#include "Constants.h"

/* SHIFT REGISTER IC PIN OUTS
        __
  Q1 -|    |- VCC
  Q2 -|    |- Q0
  Q3 -|    |- DS
  Q4 -|    |- OE
  Q5 -|    |- ST_CP
  Q6 -|    |- SH_CP
  Q7 -|    |- MR
 GND -| __ |- Q'

  Key:
  Q0 - Q7: Parallel Out Pins
  Q': Cascade Pin
  DS: Serial Data In Pin
  OE: Output Enable (GND)
  ST_CP: Latch Pin
  SH_CP: Clock Pin
  MR: Master Reset (VCC)
*/

/* PINS FOR SHIFT REG */
// ST_CP of 74HC595
#define LATCH_PIN 6
// SH_CP of 74HC595
#define CLOCK_PIN 8
// DS of 74HC595
#define DATA_PIN 7

/* CONSTANT FOR EMPTY*/
#define EMPTY B11111111

/* DEFINE AND INITIALIZE THE ARRAY WITH THE NECESSARY VALUES */
// Hex Character from 0 - F

//bit coded for each number and letter
byte hexArray[16] ={B11000000,  // 0
                    B11111001,  // 1
                    B10100100,  // 2
                    B10110000,  // 3
                    B10011001,  // 4
                    B10010010,  // 5
                    B10000010,  // 6
                    B11111000,  // 7
                    B10000000,  // 8
                    B10011000,  // 9
                    B10001000,  // A
                    B10000000,  // B
                    B11000110,  // C
                    B11000000,  // D
                    B10000110,  // E
                    B10001110   // F
                    };

void setupShiftRegister() {
  pinMode(LATCH_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);
  pinMode(DATA_PIN, OUTPUT);
  }
  
/******************sendToShiftRegister *******************************
TODO:: IMPLEMENT THE FUNCTIONALITY TO SEND THE CORRECT DATA TO 
SHIFT REG - BASED ON THE POT VAL
********************************************************************/
void sendToShiftRegister(int pot)
{
  // IMPLEMENT

  //give a byte value from the byte array

  byte value = hexArray[pot];

  // turn off the output of 74HC595
  digitalWrite(LATCH_PIN, LOW);

  //update pattern, send bit to shift register
  shiftOut(DATA_PIN, CLOCK_PIN, MSBFIRST, value);

  //turn on output
   digitalWrite(LATCH_PIN, HIGH);
}
  
  


/******************READ FROM POT*********************************
TO DO:: GET VALUE FROM POT AND ENSURE THE VALUE RETURNED IS A VALID VALUE 
********************************************************************/
int getAnalog() {

  //create int variable to store final value
  int validValue = 0;

  //read value from sensor
  int sensorValue = analogRead(A1);

  //change code to fit between numbers 0-16
  validValue = (sensorValue*16)/1023;

  //return value
  return validValue;

  
}

#endif /* SHIFTREGISTER_H_ */
